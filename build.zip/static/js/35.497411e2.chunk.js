(this["webpackJsonp@minimal/minimal-kit-react"]=this["webpackJsonp@minimal/minimal-kit-react"]||[]).push([[35],{2302:function(i,a){}}]);
//# sourceMappingURL=35.497411e2.chunk.js.map