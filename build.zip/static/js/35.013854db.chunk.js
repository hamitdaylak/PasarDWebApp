(this["webpackJsonp@minimal/minimal-kit-react"]=this["webpackJsonp@minimal/minimal-kit-react"]||[]).push([[35],{2314:function(i,a){}}]);
//# sourceMappingURL=35.013854db.chunk.js.map